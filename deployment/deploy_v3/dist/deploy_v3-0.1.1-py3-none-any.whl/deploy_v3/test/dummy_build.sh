#!/usr/bin/env bash

set -e

## test basic functionality
fivetran-cd -tvv build ./scripts/deployment_v2/tests/dummy_bazel_oci.yaml
fivetran-cd -tvv build ./scripts/deployment_v2/tests/dummy_bazel_platform.yaml
fivetran-cd -tvv build ./scripts/deployment_v2/tests/dummy_docker.yaml

## test with suffix
fivetran-cd -tvv build ./scripts/deployment_v2/tests/dummy_bazel_oci.yaml --tag-suffix test_suffix
fivetran-cd -tvv build ./scripts/deployment_v2/tests/dummy_docker.yaml --tag-suffix test_suffix

## test forced CPU type
fivetran-cd -tvv build ./scripts/deployment_v2/tests/dummy_bazel_oci.yaml --force-cpu x86
fivetran-cd -tvv build ./scripts/deployment_v2/tests/dummy_docker.yaml --force-cpu x86

## test failure (bazel command is bad)
fivetran-cd -tvv build ./scripts/deployment_v2/tests/dummy_failure.yaml && exit 1
echo "^^ the above SHOULD fail"

# check that dummy_bazel_platform.yaml pushes ARM images
SHA=$(fivetran-cd get-git-sha)

ARM_IMAGE_OCI=us-docker.pkg.dev/build-286712/prod-docker-us/dummy/bazel_arm:$SHA
docker pull "$ARM_IMAGE_OCI"

EXPECTED_ARCH="arm64"
EXPECTED_ARCH_FOR_OLD_RULES="amd64" # old rules set the wrong architecture
IMAGE_ARCH_OCI=$(docker image inspect "$ARM_IMAGE_OCI" | jq --raw-output '.[0].Architecture')

# check `Architecture` in images metadata
if [[ "$IMAGE_ARCH_OCI" != "$EXPECTED_ARCH" ]]; then
  echo "OCI image has wrong architecture: $IMAGE_ARCH_OCI instead of $EXPECTED_ARCH"
  exit 1
fi

echo "Check linux image architecture in the images"
# we can't run arm image on x86 linux (CI), exit with error if success

echo "Check $ARM_IMAGE_OCI:"
docker run "$ARM_IMAGE_OCI" uname -a && exit 1

echo "============================================="
echo "============================================="
echo "If you see this message, the tests all passed"
echo "============================================="
echo "============================================="
