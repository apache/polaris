#!/usr/bin/env bash

set -e

## test basic functionality
fivetran-cd -tvv tag ./scripts/deployment_v2/tests/dummy_bazel_oci.yaml nullspace
fivetran-cd -tvv tag ./scripts/deployment_v2/tests/dummy_docker.yaml nullspace

## test with suffix
fivetran-cd -tvv tag ./scripts/deployment_v2/tests/dummy_bazel_oci.yaml nullspace --tag-suffix test_suffix
fivetran-cd -tvv tag ./scripts/deployment_v2/tests/dummy_docker.yaml nullspace --tag-suffix test_suffix

## test with no-sha
fivetran-cd -tvv tag ./scripts/deployment_v2/tests/dummy_bazel_oci.yaml nullspace --add-no-sha-tag
fivetran-cd -tvv tag ./scripts/deployment_v2/tests/dummy_docker.yaml nullspace --add-no-sha-tag

## test with no-sha and suffix
fivetran-cd -tvv tag ./scripts/deployment_v2/tests/dummy_bazel_oci.yaml nullspace --tag-suffix test_suffix --add-no-sha-tag
fivetran-cd -tvv tag ./scripts/deployment_v2/tests/dummy_docker.yaml nullspace --tag-suffix test_suffix --add-no-sha-tag

## test failure - source image does not exist
fivetran-cd -tvv tag ./scripts/deployment_v2/tests/dummy_failure.yaml nullspace -T 30 && exit 1
echo "^^ the above SHOULD fail"

## test failure - impossible new tag
fivetran-cd -tvv tag ./scripts/deployment_v2/tests/dummy_bazel_oci.yaml inval!d && exit 1
echo "^^ the above SHOULD fail"
fivetran-cd -tvv tag ./scripts/deployment_v2/tests/dummy_bazel_oci.yaml !invalid --add-no-sha-tag && exit 1
echo "^^ the above SHOULD fail"

echo "============================================="
echo "============================================="
echo "If you see this message, the tests all passed"
echo "============================================="
echo "============================================="
