import unittest
from datetime import datetime
from pathlib import Path
from src.models.service import load_service, Service
from src.deployer import Deployer
from src.process import ProcessRunner
from src.git import clone_argocd_repo, create_argocd_repo_branch, delete_argocd_repo_branch, cleanup_argocd_temp_repo
from src.env import ARGOCD_REPO_PATH
from pathlib import Path
import yaml
from jsonpath_ng import parse
from src.env import get_repo_dir
from cli import MAIN_BRANCH

def _load_service(filename: str) -> Service:
    full_filepath = Path(filename).resolve()
    if not full_filepath.exists():
        raise FileNotFoundError(f"[filename] does not exist: {filename}")
    return load_service(full_filepath)

class MockContext():
    def __init__(self):
        self.obj = {}

class TestDeployer(unittest.TestCase):

    def setUp(self):
        self.mock_environment = "sre-test"

        # Create MockContext
        ctx = MockContext()
        ctx.obj["options"] = {}
        ctx.obj["options"]["try_all"] = True
        ctx.obj["options"]["verbose"] = 1
        ctx.obj["options"]["time"] = True
        ctx.obj["dependencies"] = {}
        ctx.obj["dependencies"]["process_runner"] = ProcessRunner(1)

        self.tmp_path = ARGOCD_REPO_PATH.resolve().as_posix()

        filename = Path(get_repo_dir(), "deployment/deploy_v3/deploy_v3/test/dummy_deploy_argocd.yaml").resolve().as_posix()
        service = _load_service(filename)
        self.deployer = Deployer(service, ctx.obj["options"]["try_all"])

        current_date = datetime.now()
        self.release_branch = f"unittest/test_create_argocd_repo_pull_request-{current_date.date()}"


    def test_git_write_back(self):
        clone_argocd_repo(MAIN_BRANCH)
        create_argocd_repo_branch(self.release_branch)

        expected_image_tag = "abcd1234-nullspace"

        # Perform the actual write-back to git
        self.deployer.git_write_back(self.mock_environment, expected_image_tag, self.release_branch)

        # Verify the write-back by cloning the repo and release-branch into a new tmp-dir,
        # loading the yaml file and checking if the image-tag has been updated.
        clone_argocd_repo(self.release_branch)

        images_values_filename = f"{self.tmp_path}/environments/{self.mock_environment}/{self.deployer._Deployer__service.deployment.application_path}/{self.deployer._Deployer__service.deployment.values_file}"

        with open(images_values_filename, "r") as values_file:
            deployment_config = yaml.safe_load(values_file)
            jsonpath_expr = parse(self.deployer._Deployer__service.deployment.image_tag_json_path)
            new_tag = jsonpath_expr.find(deployment_config)[0].value

            self.assertEqual(new_tag, expected_image_tag)

        # cleanup tmp-release branch after testing..
        delete_argocd_repo_branch(self.release_branch, self.tmp_path)


    def test_deploy_all(self):
        clone_argocd_repo(MAIN_BRANCH)
        create_argocd_repo_branch(self.release_branch)

        expected_image_tag = "abcd1234-nullspace"

        # Mock the registry
        self.deployer.__known_images = ["us-docker.pkg.dev/build-286712/prod-docker-us/dummy/bazel:abcd1234-nullspace"]
        self.deployer.deploy_all("sre-test", "abcd1234", "nullspace", "abcd1234-nullspace", 10, self.release_branch)

        # Verify the write-back by cloning the repo and release-branch into a new tmp-dir,
        # loading the yaml file and checking if the image-tag has been updated.
        clone_argocd_repo(self.release_branch)

        images_values_filename = f"{self.tmp_path}/environments/{self.mock_environment}/{self.deployer._Deployer__service.deployment.application_path}/{self.deployer._Deployer__service.deployment.values_file}"

        with open(images_values_filename, "r") as values_file:
            deployment_config = yaml.safe_load(values_file)
            jsonpath_expr = parse(self.deployer._Deployer__service.deployment.image_tag_json_path)
            new_tag = jsonpath_expr.find(deployment_config)[0].value

            self.assertEqual(new_tag, expected_image_tag)

        # cleanup tmp-release branch after testing..
        delete_argocd_repo_branch(self.release_branch, self.tmp_path)

        cleanup_argocd_temp_repo()


if __name__ == '__main__':
    unittest.main()
