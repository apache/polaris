import unittest
from pathlib import Path
from datetime import datetime
import yaml
import multiprocessing as mp
import os

import pygit2
from src.env import ARGOCD_REPO_PATH, get_repo_dir
from src.git import cleanup_argocd_temp_repo, init_repo, clone_argocd_repo, create_argocd_repo_branch, delete_argocd_repo_branch, commit_argocd_repo_changes, create_argocd_repo_pull_request


class TestGit(unittest.TestCase):
    def setUp(self):
        self.initial_checkout_branch="main"
        self.create_branch_without_checkout_without_push = "arnaudvg/test-pipeline-tests"
        self.create_branch_and_checkout_without_push = "arnaudvg/test-pipeline-tests-checkout"
        self.create_branch_and_checkout_and_push = "arnaudvg/test-pipeline-tests-checkout-and-push-testing-new"



    def test_clone_argocd_repo(self):
        # Setup testing prerequisites
        tmp_path = ARGOCD_REPO_PATH.resolve().as_posix()
        print(f"Temp repo-path: {tmp_path}")

        # Execute the function to be tested
        cloned_repo_value = clone_argocd_repo(self.initial_checkout_branch)

        # Assert the outcome
        self.assertRegex(cloned_repo_value.path, "/Fivetran/argocd-alpha/.git/$")
        self.assertTrue(cloned_repo_value.branches.get(self.initial_checkout_branch).is_checked_out())




    def test_init_repo(self):
        ##### test default/existing usage without parameter; it should return engineering repo
        # Set the expectations
        expected_repo_value = pygit2.Repository(pygit2.discover_repository(get_repo_dir()))

        # Execute function to be tested
        repo_value = init_repo(get_repo_dir())

        # Assert the outcome
        self.assertRegex(repo_value.path, "Fivetran/engineering")
        self.assertEqual(repo_value.path, expected_repo_value.path)
        self.assertEqual(repo_value.default_signature, expected_repo_value.default_signature)



        #### test when querying for engineering-repository: it should return the engineering repo
        # Set the expectations
        expected_repo_value = pygit2.Repository(pygit2.discover_repository(get_repo_dir()))

        # Execute function to be tested
        repo_value = init_repo(get_repo_dir())

        # Assert the outcome
        self.assertRegex(repo_value.path, "Fivetran/engineering")
        self.assertEqual(repo_value.path, expected_repo_value.path)
        self.assertEqual(repo_value.default_signature, expected_repo_value.default_signature)



        #### test when querying for argocd-repository: it should return the argocd repo
        # Setup testing prerequisites
        tmp_repo_path = ARGOCD_REPO_PATH.resolve().as_posix()
        print(f"Temp repo-path: {tmp_repo_path}")

        # Prepare the repository directory by cloning into the tmp_dir
        clone_argocd_repo(self.initial_checkout_branch)

        # Set the expectations
        expected_repo_value = pygit2.Repository(pygit2.discover_repository(tmp_repo_path))

        # Execute function to be tested
        repo_value = init_repo(tmp_repo_path)

        # Assert the outcome
        self.assertRegex(repo_value.path, "Fivetran/argocd-alpha")
        self.assertEqual(repo_value.path, expected_repo_value.path)
        self.assertEqual(repo_value.default_signature, expected_repo_value.default_signature)





    def test_create_argocd_repo_branch(self):
        #### test when querying for argocd-repository: it should return the argocd repo
        # Setup testing prerequisites
        tmp_repo_path = ARGOCD_REPO_PATH.resolve().as_posix()
        print(f"Temp repo-path: {tmp_repo_path}")

        # Prepare the repository directory by cloning into the tmp_dir and
        # Test that the self.initial_checkout_branch is checked out.
        cloned_repo_value = clone_argocd_repo(self.initial_checkout_branch)
        self.assertTrue(cloned_repo_value.branches.get(self.initial_checkout_branch).is_checked_out())


        # Test creation of branch without checking the branch out
        new_branch = create_argocd_repo_branch(self.create_branch_without_checkout_without_push, False, False)
        self.assertEqual(new_branch.branch_name, self.create_branch_without_checkout_without_push)
        self.assertTrue(cloned_repo_value.branches.get(self.initial_checkout_branch).is_checked_out())
        self.assertFalse(cloned_repo_value.branches.get(self.create_branch_without_checkout_without_push).is_checked_out())


        # Test creation of branch and checking the branch out
        new_branch = create_argocd_repo_branch(self.create_branch_and_checkout_without_push, True, False)
        self.assertEqual(new_branch.branch_name, self.create_branch_and_checkout_without_push)
        self.assertFalse(cloned_repo_value.branches.get(self.initial_checkout_branch).is_checked_out())
        self.assertTrue(cloned_repo_value.branches.get(self.create_branch_and_checkout_without_push).is_checked_out())
        self.assertEqual(cloned_repo_value.branches.local[self.create_branch_and_checkout_without_push].name, f"refs/heads/{self.create_branch_and_checkout_without_push}")
        with self.assertRaises(KeyError) as cm:
            cloned_repo_value.branches.remote[f"origin/{self.create_branch_and_checkout_without_push}"]
        self.assertEqual(cm.exception.args[0], f"Branch not found: origin/{self.create_branch_and_checkout_without_push}")


        # Test creation of branch and checking the branch out and push to the upstream
        new_branch = create_argocd_repo_branch(self.create_branch_and_checkout_and_push, True, True)
        self.assertEqual(new_branch.branch_name, self.create_branch_and_checkout_and_push)
        self.assertTrue(cloned_repo_value.branches.get(self.create_branch_and_checkout_and_push).is_checked_out())
        self.assertEqual(cloned_repo_value.branches.local[self.create_branch_and_checkout_and_push].name, f"refs/heads/{self.create_branch_and_checkout_and_push}")
        self.assertEqual(cloned_repo_value.branches.remote[f"origin/{self.create_branch_and_checkout_and_push}"].name, f"refs/remotes/origin/{self.create_branch_and_checkout_and_push}")


    # depends on the test_create_argocd_repo_branch
    def test_delete_argocd_repo_branch(self):
        tmp_repo_path = ARGOCD_REPO_PATH.resolve().as_posix()
        print(f"Temp repo-path: {tmp_repo_path}")

        # Prepare the repository directory by cloning into the tmp_dir and
        # Test that the self.create_branch_and_checkout_and_push is checked out.
        cloned_repo_value = clone_argocd_repo(self.create_branch_and_checkout_and_push)
        self.assertTrue(cloned_repo_value.branches.get(self.create_branch_and_checkout_and_push).is_checked_out())

        delete_argocd_repo_branch(self.create_branch_and_checkout_and_push, True)
        with self.assertRaises(KeyError) as cm:
            cloned_repo_value.branches.local[f"{self.create_branch_and_checkout_and_push}"]
        self.assertEqual(cm.exception.args[0], f"Branch not found: {self.create_branch_and_checkout_and_push}")

        with self.assertRaises(KeyError) as cm:
            cloned_repo_value.branches.remote[f"origin/{self.create_branch_and_checkout_and_push}"]
        self.assertEqual(cm.exception.args[0], f"Branch not found: origin/{self.create_branch_and_checkout_and_push}")



    def test_commit_argocd_repo_changes(self):
        tmp_repo_path = ARGOCD_REPO_PATH.resolve().as_posix()
        print(f"Temp repo-path: {tmp_repo_path}")

        # Prepare the repository directory by cloning into the tmp_dir and
        # Test that the self.initial_checkout_branch is checked out.
        cloned_repo_value = clone_argocd_repo(self.initial_checkout_branch)
        self.assertTrue(cloned_repo_value.branches.get(self.initial_checkout_branch).is_checked_out())

        # write some test-content to a file
        with open(f"{tmp_repo_path}/test-file.txt", "w") as file:
            file.write("This is the test-content in the file")

        # commit and push the changed file to github
        commit_argocd_repo_changes("test-file.txt", True)

        # cleanup after all tests are done....
        cleanup_argocd_temp_repo()



    def test_create_argocd_repo_pull_request(self):
        tmp_repo_path = ARGOCD_REPO_PATH.resolve().as_posix()

        current_date = datetime.now()
        branch_name = f"unittest/test_create_argocd_repo_pull_request-{current_date.date()}"

        clone_argocd_repo(self.initial_checkout_branch)
        create_argocd_repo_branch(branch_name)
        # write some test-content to a file
        with open(f"{tmp_repo_path}/test-file.txt", "w") as file:
            file.write(f"This is the test-content in the file {current_date}")

        # commit and push the changed file to github
        commit_argocd_repo_changes("test-file.txt", True)

        # create the pull-request
        output = create_argocd_repo_pull_request(branch_name)

        # Validate that the PR exists
        repo = output[0]
        pr = output[1]
        pull = next((pull for pull in repo.get_pulls() if pull.number == pr.number), None)
        self.assertEqual(pr.number, pull.number)

         # cleanup after all tests are done....
        cleanup_argocd_temp_repo()


    # Run this test locally only within 4 separate shells:
    # SHELL 0: mkdir test-init test-1 test-2 test-3 test-4; cd test-init; git clone git@github.com:fivetran/argocd-alpha.git .; git checkout -b <branchname>; git push --set-upstream origin <branchname>
    # SHELL 1; TMP_REPO_PATH=/tmp/argocd-test/test-1 TMP_ITEM=1 python -m unittest deploy_v3.test.py.git_test.TestGit.test_committing_argocd_repo_changes
    # SHELL 2; TMP_REPO_PATH=/tmp/argocd-test/test-2 TMP_ITEM=2 python -m unittest deploy_v3.test.py.git_test.TestGit.test_committing_argocd_repo_changes
    # SHELL 3; TMP_REPO_PATH=/tmp/argocd-test/test-3 TMP_ITEM=3 python -m unittest deploy_v3.test.py.git_test.TestGit.test_committing_argocd_repo_changes
    # SHELL 4; TMP_REPO_PATH=/tmp/argocd-test/test-4 TMP_ITEM=4 python -m unittest deploy_v3.test.py.git_test.TestGit.test_committing_argocd_repo_changes
    def test_committing_argocd_repo_changes(self):
        tmp_repo_path = os.getenv("TMP_REPO_PATH")
        ITEM = os.getenv("TMP_ITEM")
        print(f"Temp repo-path: {tmp_repo_path}")

        tmp_repo_path = Path(tmp_repo_path)

        clone_argocd_repo(self.create_branch_and_checkout_and_push, tmp_repo_path)

        if ITEM == "1":
            # write some test-content to a file
            with open(f"{tmp_repo_path}/test-file-first-repo.txt", "w") as file:
                file.write("This is the test-content in the file")
            # commit and push the changed file to github
            commit_argocd_repo_changes("test-file-first-repo.txt", True, tmp_repo_path)

        elif ITEM == "2":
            # write some test-content to a file
            with open(f"{tmp_repo_path}/environments/dev/demo/alpine/values.yaml", "r") as file:
                values_yaml  = yaml.safe_load(file)
                values_yaml["alpine"]["image"]["name"] = "test-git-commit-name"
            # write the updated image-tag back to the values-file
            with open(f"{tmp_repo_path}/environments/dev/demo/alpine/values.yaml", "w") as values_file:
                yaml.dump(values_yaml, values_file)
            # commit and push the changed file to github
            commit_argocd_repo_changes("environments/dev/demo/alpine/values.yaml", True, tmp_repo_path)


        elif ITEM == "3":
            # write some test-content to a file
            with open(f"{tmp_repo_path}/environments/dev/demo/alpine/values.yaml", "r") as file:
                values_yaml  = yaml.safe_load(file)
                values_yaml["alpine"]["image"]["tag"] = "test-git-commit-tag"
            # write the updated image-tag back to the values-file
            with open(f"{tmp_repo_path}/environments/dev/demo/alpine/values.yaml", "w") as values_file:
                yaml.dump(values_yaml, values_file)
            # commit and push the changed file to github
            commit_argocd_repo_changes("environments/dev/demo/alpine/values.yaml", True, tmp_repo_path)

        elif ITEM == "4":
            # write some test-content to a file
            print(f"updating test-file-fourth-repo.txt")
            with open(f"{tmp_repo_path}/test-file-fourth-repo.txt", "w") as file:
                file.write("This is the test-content in the file")
            # commit and push the changed file to github
            commit_argocd_repo_changes("test-file-fourth-repo.txt", True, tmp_repo_path)



if __name__ == '__main__':
    unittest.main()
