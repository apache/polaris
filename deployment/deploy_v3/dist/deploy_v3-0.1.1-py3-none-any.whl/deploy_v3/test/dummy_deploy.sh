#!/usr/bin/env bash

set -e

## test basic functionality
fivetran-cd -tvv deploy ./scripts/deployment_v2/tests/dummy_bazel_oci.yaml nullspace nullspace
fivetran-cd -tvv deploy ./scripts/deployment_v2/tests/dummy_docker.yaml nullspace nullspace

## particular tag
fivetran-cd -tvv deploy ./scripts/deployment_v2/tests/dummy_bazel_oci.yaml nullspace nullspace
fivetran-cd -tvv deploy ./scripts/deployment_v2/tests/dummy_docker.yaml nullspace nullspace --target-sha abcd1234

## particular tag + release tag
fivetran-cd -tvv deploy ./scripts/deployment_v2/tests/dummy_bazel_oci.yaml nullspace nullspace --target-sha abcd1234 --release-tag nullspace
fivetran-cd -tvv deploy ./scripts/deployment_v2/tests/dummy_docker.yaml nullspace nullspace --target-sha abcd1234 --release-tag nullspace

# testing of command execution and substitution
fivetran-cd -tvv deploy ./scripts/deployment_v2/tests/dummy_deploy_command.yaml nullspace nullspace

cat > expected.yml << EOL
deploy:
  data:
    MIGRATION_JOB_IMAGE: us-docker.pkg.dev/build-286712/prod-docker-us/dummy/bazel:abcd1234-nullspace
  namespace: nullspace
  overrided: nullspace-overrided
  runnerImage: us-docker.pkg.dev/build-286712/prod-docker-us/dummy/bazel:abcd1234-nullspace
  tag: abcd1234-nullspace
EOL

diff result.yml expected.yml || {
  echo "Expected:"
  cat expected.yml
  echo "Result:"
  cat result.yml
  exit 1
}

echo "============================================="
echo "============================================="
echo "If you see this message, the tests all passed"
echo "============================================="
echo "============================================="
