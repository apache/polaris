from os.path import dirname, abspath
import sys

# Find code directory relative to our directory
current_dir = abspath(dirname(__file__))
sys.path.append(current_dir)
