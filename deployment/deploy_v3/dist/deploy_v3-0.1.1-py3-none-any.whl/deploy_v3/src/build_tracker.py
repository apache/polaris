import logging
import requests
import json
from datetime import datetime

class BuildTracker:
    def __init__(self, hostname, token):
        log = logging.getLogger(__name__)
        self.url =  f"{hostname}/build"
        self.headers = {'Authorization': 'Basic {}'.format(token)}
        log.warning(f"Connecting to {self.url} with {self.headers}")

    def last_used_id(self):
        builds = requests.get(self.url, headers = self.headers)
        print(builds.text)
        if builds.status_code == 200:
            return sorted(
                        list(map(lambda x : x['id'], json.loads(builds.text)))
                    )[-1]
        else:
            raise BuildTrackerServiceException(f"Bad status code querying BuildTracker: {builds.status_code}, {builds.text}")
                
    def new_allowed_build(self, build_id, build_string):
        date = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        # 2022-11-02T01:01:01Z
        body = {
            "id": build_id,
            "tag": build_string,
            "released_at": date,
            "allowed": True
        }
        resp = requests.post(self.url, json = body, headers = self.headers)
        if resp.status_code != 201:
            raise BuildTrackerServiceException(f"Bad status code updating BuildTracker: {resp.status_code}, {resp.text}")

class BuildTrackerServiceException(Exception):
    pass

if __name__ == "__main__":
    bt = BuildTracker("https://staging.gcp.global.build-tracker.fivetran.com","TEST_TOKEN")
    build_id = bt.last_used_id() + 1
    bt.new_allowed_build(build_id, "integration-2.0.0-20230202") 
