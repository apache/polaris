import logging
import os
from pathlib import Path

from src.fivetran_logging.formatter import setup_logging
from src.fivetran_logging.timer import DEFAULT_WRITER

import pygit2
log = logging.getLogger(__name__)
possible_dirs = [
    os.getenv('CIRCLE_WORKING_DIRECTORY', "~/root"),  # circleci default
    ".",  # current dir
    "~/Fivetran/engineering",  # dev laptop default
    "../..",  # we might be in the deployment/v3 dir
]

ARGOCD_REPO_PATH = Path("/home/buildkite/argocd")

def get_repo_dir():
    print(possible_dirs)
    for repo_dir in possible_dirs:
        print(repo_dir)
        log.debug(f"Checking repo_dir: {repo_dir}")
        repo_path = Path(os.path.expanduser(repo_dir))
        if repo_path.exists() and _is_eng_repo(repo_path):
            return repo_path.resolve()
    raise NotADirectoryError("Unable to find the engineering directory root path.")

def _is_eng_repo(repo_path: Path):
    repo_path_git = pygit2.discover_repository(repo_path)
    if repo_path_git == None:
        return False
    repo =  pygit2.Repository(repo_path_git)
    if (("fivetran/engineering" in repo.remotes["origin"].url.lower() or
         "fivetran/polaris" in repo.remotes["origin"].url.lower())
            and Path(repo.path).parent.absolute() == repo_path.resolve()):
        return True

def is_argocd_repo(repo_path: Path):
    repo_path_git = pygit2.discover_repository(repo_path)
    if repo_path_git == None:
        return False
    repo =  pygit2.Repository(repo_path_git)
    if ("fivetran/argocd-alpha" in repo.remotes["origin"].url.lower()
            and Path(repo.path).parent.absolute() == repo_path.resolve()):
        return True

def init_script(verbosity: int, use_timer: bool = False, timer_script_name: str = ""):
    setup_logging(verbosity)

    DEFAULT_WRITER.enabled = use_timer
    DEFAULT_WRITER.script_name = timer_script_name

    # move to the engineering root dir
    repo_dir = get_repo_dir()
    os.chdir(repo_dir)
    log.debug(f"Changing directory to: {repo_dir}")

def get_git_ssh_keys() -> tuple[str, str]:
    ssh_private_key = os.environ.get("GITHUB_SSH_PRIVATE_KEY")
    ssh_public_key = os.environ.get("GITHUB_SSH_PUBLIC_KEY")

    return ssh_public_key, ssh_private_key

def get_argocd_github_access_token():
    return os.environ.get("ARGOCD_GITHUB_ACCESS_TOKEN")
