import logging
import subprocess
import time
from dataclasses import dataclass, field

from src.fivetran_logging.timer import DEFAULT_WRITER
from src.models.service import Service, Build
from src.process import ProcessRunner
from src.registry import get_registry, Registry, GcrRegistry, ArtifactRegistry

from typing import List

log = logging.getLogger(__name__)


@dataclass
class TagBuilder:
    sha: str = ""
    base: str = ""
    suffix: str = ""
    extra_tags: list = field(default_factory=lambda: [])

    def get_build_tag(self) -> str:
        if self.suffix:
            return f"{self.sha}_{self.suffix}"
        else:
            return self.sha

    def get_deployment_tag(self) -> str:
        return f"{self.sha}-{self.get_no_sha_deployment_tag()}"

    def get_no_sha_deployment_tag(self) -> str:
        if self.suffix:
            return f"{self.base}_{self.suffix}"
        else:
            return f"{self.base}"


@dataclass
class Tagger:
    service: Service
    tag_builder: TagBuilder
    runner: ProcessRunner
    add_no_sha_tag: bool
    timeout: int
    try_all: bool
    build_name: str

    def tag_all(self):
        log.warning(f"Tagging images for {self.service.name}")
        t_all = DEFAULT_WRITER.new_timer(f"{self.service.name} -- total")
        retval = True
        foundImage=True
        try:
            if self.build_name == "all": 
                for build in self.service.builds.values():
                    t = DEFAULT_WRITER.new_timer(f"{self.service.name} -- {build.name}")
                    try:
                        if build.buildImage:
                            self.tag(build)
                        else:
                            log.warning(f"Skipping tagging '{build.name}': Build image generation is disabled.")
                    except BaseException as e:
                        log.error(f"Failed to tag '{build.name}': {e}")
                        if not self.try_all:
                            return False
                        else:
                            retval = False
                    finally:
                        t.stop()
            else:
                for build in self.service.builds.values():
                    if self.build_name == build.name:
                        foundImage = True
                        t = DEFAULT_WRITER.new_timer(f"{self.service.name} -- {build.name}")
                        try:
                            self.tag(build)
                        except BaseException as e:
                            log.error(f"Failed to tag '{build.name}': {e}")
                            if not self.try_all:
                                return False
                            else:
                                retval = False
                        finally:
                            t.stop()
                    else:
                        foundImage = False                                                
        finally:
            if foundImage == False:
                log.error(f"{self.build_name} not found in build config.")
            t_all.stop()
        return retval

    def tag(self, build: Build):
        build_image = build.full_image_name(self.tag_builder.get_build_tag())
        deploy_image = build.full_image_name(self.tag_builder.get_deployment_tag())
        no_sha_deploy_image = build.full_image_name(self.tag_builder.get_no_sha_deployment_tag())
        extra_build_tags = map(build.full_image_name, self.tag_builder.extra_tags)

        target_registry = get_registry(build.registry, self.runner)
        if target_registry == None:
            log.warning(f"Skipping tag for '{build.name}': invalid registry {build.registry}")
            return
        if not target_registry.confirm_image_exists(build_image, self.timeout):
            raise ImageNotFoundException(f"Image {build_image} is not in GCR after waiting {self.timeout} seconds.")
        target_registry.add_tag(build_image, deploy_image)
        if self.add_no_sha_tag:
            target_registry.add_tag(build_image, no_sha_deploy_image)
        for extra_tag in extra_build_tags:
            target_registry.add_tag(build_image, extra_tag)

class ImageNotFoundException(Exception):
    pass
