argocd_pr_commit_message='''
release of {branch_name}

## Change Control
Refer to [Slab](https://fivetran.slab.com/posts/fivetran-change-control-process-hqc8jk18) for complete details.

<!-- Ex. 27 July 2021 -->
- Date of Change: {date}
- Success Criteria is: changed images are successfully deployed
- Is there a Security Impact?
  - [x] <!--sec-no--> NO
  - [ ] <!--sec-ys--> YES. I have added a member of the Fivetran Security Team for review.
- Is this tied to an incident?
  - [x] <!--incident-no--> NO
  - [ ] <!--incident-ys--> YES. Height ticket: T-XXXXX

<!-- This is enforced via a PR check -->
Please add one of the following `production-impact:*` labels:
- `production-impact:none`
  - Change is to a non-production system, or change can not impact customer workflows
- `production-impact:minimal`
  - Change may have customer impact, but is not expected to, or it can be easily mitigated
- `production-impact:potential-disruption`
  - Any interruption is not expected, but may happen and customer notification is required. Alternatively, an API or interface is changing in a potentially breaking way
- `production-impact:scheduled-downtime`
  - One or more Fivetran services will be unavailable and downtime must be scheduled in advance. Customer Support will use Fivetran communication channels to co-ordinate and schedule the downtime

<!-- This is enforced via a PR check -->
Please add the `production-change:planned` label, then update it to `production-change:(completed|failed)` once the PR is merged.


<!--
If `production-impact` is `potential-disruption` or `scheduled-downtime`, you MUST complete the below sections:
-->
### Change Review

#### Rollout Plan
<!--
If already included in PR (the code), mention which file contains the plan.

Step-by-step procedure for any manually-executed steps. If automation (Atlantis or Argo) will roll out the change on merge, this section is not necessary.
-->
<!--rollout-start-->

<!--rollout-end-->
#### Rollback Plan
<!--
If already included in PR (the code), mention which file contains the plan.

Step-by-step procedure to execute in event of an error. If this is a Standard change and typical Change Rollback procedures are sufficient this section is not necessary.
-->
<!--rollback-start-->

<!--rollback-end-->
#### Testing History or Plan
<!--
Has this been tested in a lower environment (IE, staging?) Link to Deployment PR or any test results
-->
<!--testing-start-->

<!--testing-end-->
'''
