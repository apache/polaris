import logging
import os
import copy
from subprocess import run, CompletedProcess, CalledProcessError, PIPE
from dataclasses import dataclass
from typing import List

from retry import retry

log = logging.getLogger(__name__)


@dataclass
class ProcessRunner:
    verbosity: int

    @retry(CalledProcessError, tries=3, delay=1, backoff=2)
    def run_retry(self, cmd: List[str], env: dict = {}):
        log.info(f"Running: {cmd}")
        run(cmd, check=True, capture_output=(self.verbosity < 2), env=self.extend_env(env))

    def run_once(self, cmd: List[str], env: dict = {}):
        log.info(f"Running: {cmd}")
        run(cmd, check=True, capture_output=(self.verbosity < 2), env=self.extend_env(env))

    def run_command(self, cmd: str, env: dict = {}) -> CompletedProcess:
        log.info(f"Running: {cmd}")
        return run(cmd, check=True, shell=True, stdout=PIPE, env=self.extend_env(env))

    @retry(CalledProcessError, tries=3, delay=1, backoff=2)
    def run_command_retry(self, cmd: str, env: dict = {}) -> CompletedProcess:
        log.info(f"Running: {cmd}")
        return run(cmd, check=True, shell=True, stdout=PIPE, env=self.extend_env(env))

    def extend_env(self, additional_env_vars: dict) -> dict:
        env_copy = copy.deepcopy(os.environ)
        env_copy.update(additional_env_vars)
        return env_copy
