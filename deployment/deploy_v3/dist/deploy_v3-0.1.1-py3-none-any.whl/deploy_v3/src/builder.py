import logging
import os
from dataclasses import dataclass
from pathlib import Path
from shlex import split
from typing import List

from toposort import toposort_flatten

from src.fivetran_logging.timer import DEFAULT_WRITER
from src.models.service import Service, Build, BuildType
from src.process import ProcessRunner
from src.tagger import TagBuilder

log = logging.getLogger(__name__)


@dataclass
class Builder:
    service: Service
    tag_builder: TagBuilder
    runner: ProcessRunner
    try_all: bool
    skip_push: bool
    build_name: str
    force_cpu: str

    def build_all(self):        
        log.warning(f"Building Docker images for {self.service.name}")
        t_all = DEFAULT_WRITER.new_timer(f"{self.service.name} -- total")
        retval = True
        try:
            if self.build_name == "all":
                for bn in self.determine_build_order():
                    if bn in self.service.builds:
                        t = DEFAULT_WRITER.new_timer(f"{self.service.name} -- {bn}")
                        try:
                            self.build(self.service.builds[bn])
                        except BaseException as e:
                            log.error(f"Failed to build '{bn}': {e}")
                            if not self.try_all:
                                return False
                            else:
                                retval = False
                        finally:
                            t.stop()
                    else:
                        log.warning(f"Skipping build '{bn}': does not exist (check 'required_builds')")
            else:
                if self.build_name in self.service.builds:
                    t = DEFAULT_WRITER.new_timer(f"{self.service.name} -- {self.build_name}")
                    self.service.builds[self.build_name].buildImage = True
                    try:
                        self.build(self.service.builds[self.build_name])
                    except BaseException as e:
                        log.error(f"Failed to build '{self.build_name}': {e}")
                        if not self.try_all:
                            return False
                        else:
                            retval = False
                    finally:
                        t.stop()
                else:
                    log.warning(f"Skipping build '{self.build_name}': does not exist (check 'required_builds')")
        finally:
            t_all.stop()

        return retval

    def build(self, build: Build):
        image_name = build.full_image_name(self.tag_builder.get_build_tag())

        log.warning(f"START : {build.name} => {image_name}")
        self.run_prepare_commands(build)
        
        if build.buildImage == True:
            if build.type == BuildType.bazel_push:
                self.build_bazel_push(build)
            elif build.type == BuildType.bazel_push_oci:
                self.build_bazel_push_oci(build)
            elif build.type == BuildType.docker_file:
                self.build_docker_file(build, image_name)
            else:
                log.warning(f"Skipping build '{build.name}': invalid build type")
                return
        else:
            log.warning(f"Skipping build '{build.name}': Build image generation is disabled.")
            return

        self.apply_local_tags(build, image_name)
        log.warning(f"DONE : {image_name}")


    # Used for `rules_docker` targets (soon to become deprecated)
    def build_bazel_push(self, build: Build):
        log.info(f"Using bazel")

        build_defs = [
            "--define", f"tag_name={self.tag_builder.get_build_tag()}",
            "--define", f"tag={self.tag_builder.get_build_tag()}",
            "--define", f"repository={build.repository}",
            "--define", f"registry={build.registry}",
            "--define", f"image={build.image}",
        ]
        for key, val in build.bazel_run_defs.items():
            build_defs.append("--define")
            build_defs.append(f"{key}={val}")

        self._bazel_run(build.bazel_path, build_defs, build.additional_bazel_config)


    # Used for `rules_oci` targets (replacement of `rules_docker`)
    def build_bazel_push_oci(self, build: Build):
        log.info(f"Using bazel")

        build_defs = []
        for key, val in build.bazel_run_defs.items():
            build_defs.append("--define")
            build_defs.append(f"{key}={val}")

        build.additional_bazel_config.append("--stamp")
        build.additional_bazel_config.append("--")
        build.additional_bazel_config.append(f"--tag={self.tag_builder.get_build_tag()}")
        build.additional_bazel_config.append(f"--repository={build.registry}/{build.repository}/{build.image}")

        self._bazel_run(build.bazel_path, build_defs, build.additional_bazel_config)


    def _bazel_run(self, target: str, defs: List[str], args: List[str]):
        if self.force_cpu == "x86":
            args.insert(0, "--//:force-cpu=x86_64")
        cmd = ["bazel", "run", target] + defs + args
        self.runner.run_retry(cmd)

    def build_docker_file(self, build: Build, image_name: str):        
        log.info(f"Using docker")

        for bazel_dep in build.bazel_deps:            
            log.info(f"Building bazel dependency target {bazel_dep}")
            self._bazel_build(build.additional_bazel_config + [bazel_dep])

        for docker_dep in build.docker_deps:
            self._copy_dependency(docker_dep, build.workdir)

        build_args = []
        for key, val in build.docker_build_args.items():
            build_args.append("--build-arg")
            build_args.append(f"{key}={val}")

        if build.docker_file:
            dockerfile_path = str(build.docker_file)
        else:
            dockerfile_path = os.path.join(build.workdir, "Dockerfile")

        if not os.path.exists(dockerfile_path):
            raise FileNotFoundError(f"dockerfile_path does not exist: {dockerfile_path}")

        if (self.force_cpu == "x86"):
            self._docker_buildx("linux/amd64", image_name, dockerfile_path, build_args, str(build.workdir))
        else:
            self._docker_build(image_name, dockerfile_path, build_args, str(build.workdir))

        if self.skip_push:
            log.info("Skipping push to registry")
        else:
            self._docker_push(image_name)

    def _docker_push(self, image_name: str):
        cmd = ["docker", "push", image_name]
        self.runner.run_retry(cmd)

    def _docker_build(self, image_name: str, dockerfile: str, build_args: List[str], workdir: str):
        cmd = ["docker", "build", "-t", image_name, "-f", dockerfile] + build_args + [workdir]
        self.runner.run_retry(cmd)

    def _docker_buildx(self, platform: str, image_name: str, dockerfile: str, build_args: List[str], workdir: str):
        cmd = ["docker", "buildx", "build", "--platform", platform, "-t", image_name, "-f", dockerfile] + build_args + [workdir]
        self.runner.run_retry(cmd)

    def _bazel_build(self, args: List[str]):
        cmd = ["bazel", "build"] + args
        self.runner.run_retry(cmd)

    def _copy_dependency(self, dependency: Path, workdir: Path):
        if dependency.parent != workdir:
            cmd = ["cp", "-f", dependency, workdir]
            self.runner.run_retry(cmd)

    def run_prepare_commands(self, build: Build):
        if len(build.prepare_commands) == 0:
            return
        log.info(f"Running prepare commands:")
        for cmd in build.prepare_commands:
            self.runner.run_retry(split(cmd))

    def apply_local_tags(self, build: Build, image_name: str):
        for local_tag in build.local_tags:
            cmd = ["docker", "tag", image_name, local_tag]
            self.runner.run_retry(cmd)

    def determine_build_order(self) -> List[str]:
        # build graph to sort
        graph = {}
        for name, build in self.service.builds.items():
            graph[name] = build.required_builds
        return toposort_flatten(graph, sort=True)
