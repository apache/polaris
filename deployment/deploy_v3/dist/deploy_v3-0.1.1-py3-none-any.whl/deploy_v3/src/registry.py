import logging
import subprocess
import time
import re
from abc import ABCMeta, abstractmethod
import sys
import os
import boto3
import botocore

from src.fivetran_logging.timer import DEFAULT_WRITER
from src.models.service import Service, Build
from src.process import ProcessRunner

log = logging.getLogger(__name__)
SLEEP_DURATION = 15


class Registry:
    def __init__(self, runner: ProcessRunner):
        self.runner = runner

    def add_tag(self, src_image: str, new_image: str) -> bool:
        log.warning(f"Adding tag {new_image} to {src_image}")
        self.runner.run_retry(self.add_tag_cmd(src_image, new_image))

    def confirm_image_exists(self, image: str, timeout: int) -> bool:
        timeout_ns = timeout * 1e09
        start = time.monotonic_ns()
        while True:
            if self.image_exists(image):
                return True
            if time.monotonic_ns() - start > timeout_ns:
                return False
            log.warning(
                f"Image {image} is not in Registry. Sleeping {SLEEP_DURATION}s..."
            )
            time.sleep(SLEEP_DURATION)

    def image_exists(self, image: str) -> bool:
        try:
            self.runner.run_once(self.image_exists_cmd(image))
            return True
        except subprocess.CalledProcessError:
            # don't output the error, we expect it to fail sometimes
            return False

    @abstractmethod
    def add_tag_cmd(self, src_image: str, new_image: str) -> bool:
        pass

    @abstractmethod
    def image_exists_cmd(self, image):
        pass


class GcrRegistry(Registry):
    def add_tag_cmd(self, src_image: str, new_image: str) -> bool:
        return [
            "gcloud",
            "container",
            "images",
            "add-tag",
            "--quiet",
            src_image,
            new_image,
        ]

    def image_exists_cmd(self, image: str) -> bool:
        return ["gcloud", "container", "images", "describe", image]


class ArtifactRegistry(Registry):
    def add_tag_cmd(self, src_image, new_image):
        return [
            "gcloud",
            "artifacts",
            "docker",
            "tags",
            "add",
            "--quiet",
            src_image,
            new_image,
        ]

    def image_exists_cmd(self, image):
        return ["gcloud", "artifacts", "docker", "images", "describe", image]


class AzureContainerRegistry(Registry):
    
    def set_azure_subscription(self,subscription_name_or_id):
        """
        Configures the Azure subscription using the Azure CLI. This method is intended to override 
        the subscription for the staging environment, as the ACR in use resides in the production account.
        """
        command = ["az", "account", "set", "--subscription", subscription_name_or_id]
        try:
            result = subprocess.run(
                command, 
                capture_output=True, 
                text=True
            )
            return {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode
            }
        except Exception as e:
            return {"error": str(e)}

    def add_tag_cmd(self, src_image, new_image):
        # Extract the repository and image details
        src_repo_name = src_image.split("/")[0]
        src_image_name = "/".join(src_image.split("/")[1:]).split(":")[0]
        src_image_tag = src_image.split("/")[-1].split(":")[1]

        new_repo_name = new_image.split("/")[0]
        new_image_name = "/".join(new_image.split("/")[1:]).split(":")[0]
        new_image_tag = new_image.split("/")[-1].split(":")[1]

        subscriptionId = os.getenv("AZURE_SUBSCRIPTION_ID","6d755170-32cd-4a50-8bf2-621c984f3528")
        result = self.set_azure_subscription(subscriptionId)

        if result.get("error"):
            log.warning("Error occured: ", result["error"])
        elif result["returncode"] == 0:
            log.info("Azure subscription set successfully!")
        else:
            log.error("Failed to set Azure subscription: " + result["stderr"])

        # Use Azure CLI to tag the image in ACR
        return [
            "az", "acr", "import",
            "--name", new_repo_name,
            "--source", f"{src_repo_name}/{src_image_name}:{src_image_tag}",
            "--image", f"{new_image_name}:{new_image_tag}",
            "--force",
            "--output", "none",
        ]

    def image_exists_cmd(self, image: str):
        # Extract the repository and image details
        repo_name = image.split("/")[0]
        image_name = "/".join(image.split("/")[1:]).split(":")[0]
        image_tag = image.split("/")[-1].split(":")[1]

        subscriptionId = os.getenv("AZURE_SUBSCRIPTION_ID","6d755170-32cd-4a50-8bf2-621c984f3528")
        result = self.set_azure_subscription(subscriptionId)

        if result.get("error"):
            log.error(result["error"])
        elif result["returncode"] == 0:
            log.info("Azure subscription set successfully!")
        else:
            log.error("Failed to set Azure subscription: " + result["stderr"])

        # Use Azure CLI to check if the image exists in the ACR
        return [
            "az", "acr", "repository", "show-tags",
            "--name", repo_name,
            "--repository", image_name,
            "--query", f"[?(@=='{image_tag}')]",
            "--output", "json"
        ]


class ElasticContainerRegistry(Registry):

    def add_tag_cmd(self, src_image, new_image):
        registry_name = src_image.split("/")[0]
        ecr_repo_name = "/".join(src_image.split("/")[1:]).split(":")[0]
        repo_name = registry_name + "/" + ecr_repo_name

        srcImageTag = src_image.split(":")[1]
        newImageTag = new_image.split(":")[1]

        try:
            profile_name = os.getenv("profileName")
            session = boto3.session.Session(profile_name=profile_name)
            ecr_client = session.client("ecr")

            response = ecr_client.batch_get_image(
                repositoryName=ecr_repo_name,
                imageIds=[
                    {"imageTag": srcImageTag},
                ],
            )
            if "images" not in response or len(response["images"]) == 0:
                print(
                    f"Image with tag '{srcImageTag}' not found in repository '{repo_name}'."
                )
                return

            image_manifest = response["images"][0]["imageManifest"]

            try:
                ecr_client.put_image(
                    repositoryName=ecr_repo_name,
                    imageManifest=image_manifest,
                    imageTag=newImageTag,
                )
                print(
                    f"Successfully retagged image '{repo_name}:{srcImageTag}' "
                    f"to '{repo_name}:{newImageTag}'."
                )

            except botocore.exceptions.ClientError as e:
                if e.response["Error"]["Code"] == "ImageAlreadyExistsException":
                    print(
                        f"Tag '{newImageTag}' already exists in repository '{repo_name}'."
                    )
                else:
                    print(f"Unhandled exception: {e}", file=sys.stderr)
                    sys.exit(1)

        except Exception as e:
            print(f"Error retagging image: {str(e)}")
            sys.exit(1)

        return ["docker", "manifest", "inspect", new_image]

    def image_exists_cmd(self, image):
        return ["docker", "manifest", "inspect", image]


def get_registry(registry_name: str, runner: ProcessRunner) -> Registry:
    if re.compile(r".*gcr\.io").match(registry_name):
        return GcrRegistry(runner)
    elif re.compile(r".*docker\.pkg\.dev").match(registry_name):
        return ArtifactRegistry(runner)
    elif re.compile(r"\d{12}\.dkr\.ecr\.[a-z0-9-]+\.amazonaws\.com").match(
        registry_name
    ):
        return ElasticContainerRegistry(runner)
    elif re.compile(r".*\.azurecr\.io").match(registry_name):
        return AzureContainerRegistry(runner)
    else:
        return None
