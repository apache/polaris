import logging
from subprocess import CalledProcessError
from src.process import ProcessRunner
from time import sleep
import copy
import os

from src.models.environments import Cluster, Provider

log = logging.getLogger(__name__)


class Auth:
    __runner: ProcessRunner = ProcessRunner(2)
    __cluster: Cluster = None
    __provider: Provider = None
    __kubecfg_env: dict = None
    __kubeconfig: str = None
    __retries = 3

    def __init__(self, cluster: Cluster, provider: Provider):
        self.__provider = provider
        self.__cluster = cluster
        self.__kubeconfig = f"{os.environ['HOME']}/.kube/{provider.name}{cluster.name}"
        self.__kubecfg_env = {'KUBECONFIG': self.__kubeconfig}

    def get_gcp_settings(self) -> list[str]:
        settings = ["--project", self.__cluster.project]
        if self.__cluster.region != None:
            settings.extend(["--region", self.__cluster.region])
        if self.__cluster.zone != None:
            settings.extend(["--zone", self.__cluster.zone])
        return settings

    def get_aws_settings(self) -> list[str]:
        settings = []
        if self.__cluster.profile == "staging":
            settings = ["--role-arn", "arn:aws:iam::232994254633:role/eks-admin",
                        "--profile", self.__cluster.profile]
        elif self.__cluster.profile == "staging-gov":
            settings = ["--role-arn", "arn:aws-us-gov:iam::065077353636:role/eks-admin",
                        "--profile", self.__cluster.profile]
        elif self.__cluster.profile == "prod-gov":
            settings = ["--role-arn", "arn:aws-us-gov:iam::087945585302:role/eks-admin",
                        "--profile", self.__cluster.profile]
        else:
            settings = ["--role-arn",
                        "arn:aws:iam::834469178297:role/eks-admin"]

        settings.extend(["--region", self.__cluster.region])
        return settings

    def get_azure_subscription_id(self) -> str:
        return "baae1669-ecf4-460c-9ba9-5a09b2fc8f14" if self.__cluster.profile == "staging" else "6d755170-32cd-4a50-8bf2-621c984f3528"

    def run_with_retry(self, commands: list[list[str]]) -> bool:
        retries = 0
        while retries < self.__retries:
            try:
                for command in commands:
                    self.__runner.run_once(command, env=self.__kubecfg_env)
                return True
            except CalledProcessError:
                retries += 1
                sleep(5)
                continue
        return False

    def auth_gcp(self) -> bool:
        command = [
            "gcloud",
            "container",
            "clusters",
            "get-credentials",
            self.__cluster.name
        ]
        command.extend(self.get_gcp_settings())

        return self.run_with_retry([command])

    def auth_aws(self) -> bool:
        command = [
            "aws",
            "eks",
            "update-kubeconfig",
            "--name",
            self.__cluster.name,
            "--kubeconfig",
            self.__kubeconfig
        ]
        command.extend(self.get_aws_settings())

        return self.run_with_retry([command])

    def auth_azure(self) -> bool:
        subscription_id = self.get_azure_subscription_id()
        commands = [[
            "az",
            "account",
            "set",
            "--subscription",
            subscription_id
        ], [
            "az",
            "aks",
            "get-credentials",
            "--resource-group",
            self.__cluster.resource_group,
            "--name",
            self.__cluster.name,
            "--file",
            self.__kubeconfig
        ]]
        return self.run_with_retry(commands)

    def auth(self):
        auth_result = True
        if self.__provider == Provider.gcp:
            auth_result = self.auth_gcp()
        elif self.__provider == Provider.aws:
            auth_result = self.auth_aws()
        elif self.__provider == Provider.azure:
            auth_result = self.auth_azure()
        else:
            auth_result = False
            log.error("Unknown provider")

        if auth_result == False:
            log.error(
                f"Failed to authenticate with {self.__provider.name} cluster: {self.__cluster.name}")
        return auth_result

    def get_kubeconfig_env(self):
        return self.__kubecfg_env;
