import logging
import math
import os
import time

log = logging.getLogger(__name__)


class Timer:
    id: str
    start: int = 0
    end: int = 0
    writer = None

    def __init__(self, id: str, writer=None):
        self.id = id
        self.start = time.perf_counter_ns()
        self.writer = writer

    def is_stopped(self):
        return self.end > 0

    def stop(self):
        if self.is_stopped():
            return
        self.end = time.perf_counter_ns()
        if self.writer:
            self.writer.record_timer(self)

    def get_duration_ns(self):
        if not self.is_stopped():
            raise TimerNotClosedException()
        return self.end - self.start

    def get_duration_s(self):
        return math.ceil(self.get_duration_ns() / 1E+09)


class Writer:
    filename: str
    enabled: bool = False
    script_name: str = ""

    def __init__(self, filename="/tmp/v3-timers.log"):
        self.filename = filename

    def new_timer(self, id: str):
        return Timer(id, self)

    def describe(self):
        if self.enabled:
            log.warning(f"Timer output written to {self.filename}")

    def record_timer(self, timer: Timer):
        if not self.enabled:
            return
        if not timer.is_stopped():
            raise TimerNotClosedException()

        msg = f"PID: {os.getpid()}, ID: {timer.id}, Seconds: {timer.get_duration_s()}"
        if self.script_name:
            msg = f"SCRIPT: {self.script_name}, {msg}"

        log.info(f"TIMING: {msg}")
        with open(self.filename, "a") as file:
            file.write(msg + "\n")


class TimerNotClosedException(Exception):
    pass


DEFAULT_WRITER = Writer()
