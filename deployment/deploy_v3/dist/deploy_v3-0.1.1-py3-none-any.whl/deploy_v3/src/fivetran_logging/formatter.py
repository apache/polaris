import logging

SUCCESS_LEVEL = logging.CRITICAL - 1


def setup_logging(verbosity: int):
    logging.SUCCESS = SUCCESS_LEVEL
    logging.addLevelName(SUCCESS_LEVEL, "SUCCESS")
    h = logging.StreamHandler()
    h.setFormatter(Formatter())
    logging.basicConfig(level=verbosity_to_level(verbosity), handlers=[
        h
    ])


def verbosity_to_level(verbosity: int):
    level = logging.WARNING
    if verbosity == 0:
        level = logging.WARNING
    elif verbosity == 1:
        level = logging.INFO
    elif verbosity == 2:
        level = logging.INFO
        # AND show subprocess output (controlled via ProcessRunner)
    elif verbosity == 3:
        level = logging.DEBUG
    return level


def log_exit_status(logger: logging.Logger, exit_code: int):
    if exit_code > 0:
        logger.log(logging.CRITICAL, "Script finished with error")
    else:
        logger.log(SUCCESS_LEVEL, "Script finished successfully")


class Formatter(logging.Formatter):
    def format(self, record):
        log_fmt = self.get_format(record.levelno, record.threadName == 'MainThread')
        formatter = logging.Formatter(log_fmt, self.datefmt)
        return formatter.format(record)

    def get_format(self, level, isMainThread):
        grey = "\x1b[38;20m"
        yellow = "\x1b[33;20m"
        red = "\x1b[31;20m"
        bold_red = "\x1b[31;1m"
        bold_green = "\x1b[32;1m"
        reset = "\x1b[0m"
        format = "%(asctime)s : %(levelname)s : %(name)s : %(message)s"
        thread_format = "%(asctime)s : %(levelname)s : %(name)s [%(threadName)s]: %(message)s"
        datefmt = '%Y-%m-%dT%H:%M:%S'

        format_to_use = format if isMainThread else thread_format

        FORMATS = {
            logging.DEBUG: grey + format_to_use + reset,
            logging.INFO: grey + format_to_use + reset,
            logging.WARNING: yellow + format_to_use + reset,
            logging.ERROR: red + format_to_use + reset,
            logging.CRITICAL: bold_red + format_to_use + reset,
            SUCCESS_LEVEL: bold_green + format_to_use + reset
        }

        return FORMATS.get(level)
