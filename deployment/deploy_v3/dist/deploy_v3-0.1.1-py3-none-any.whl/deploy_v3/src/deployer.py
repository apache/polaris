import logging
import threading
import concurrent.futures
from src.auth import Auth
from src.models.service import Service, DeploymentType
from src.models.environments import Environments, Provider
from src.tagger import TagBuilder
from src.process import ProcessRunner
from src.registry import get_registry
from src.fivetran_logging.timer import DEFAULT_WRITER
from src.git import clone_argocd_repo, commit_argocd_repo_changes
from src.env import ARGOCD_REPO_PATH
import yaml
from jsonpath_ng import parse

log = logging.getLogger(__name__)
MAX_THREADS = 16


class Deployer:
    __environments: Environments = None
    __service: Service = None
    __known_images: list[str] = None
    __try_all: bool = None

    def __init__(self, service: Service, try_all: bool):
        self.__environments = Environments()
        self.__service = service
        self.__known_images = []
        self.__try_all = try_all

    def deploy_all(self, environment: str, base_tag: str, sha: str, release_tag: str, timeout: int, release_branch: str) -> bool:
        if self.__service.deployment.type == DeploymentType.command:
            log.info("Starting legacy deploy all...")
            return self.legacy_deploy_all(environment, base_tag, sha, release_tag, timeout)
        elif self.__service.deployment.type == DeploymentType.argocd:
            log.info("Starting ArgoCD deploy all...")
            return self.argocd_deploy_all(environment, base_tag, sha, release_tag, timeout, release_branch)

    def legacy_deploy_all(self, environment: str, base_tag: str, sha: str, release_tag: str, timeout: int) -> bool:
        self.__known_images: list[str] = []
        t_all = DEFAULT_WRITER.new_timer(f"{self.__service.name} -- total")
        all_success = True
        found = False

        for service_env_name in self.__service.environments:
            if service_env_name == environment:  # found a target
                found = True
                service_env = self.__service.environments[service_env_name]
                build_name = service_env.build
                build = self.__service.builds.get(build_name)

                futures = {}
                with concurrent.futures.ThreadPoolExecutor(max_workers = MAX_THREADS) as executor:
                    for target_env in service_env.targets:
                        global_env = self.__environments.get_environment_by_name(target_env)
                        provider: Provider = global_env.provider
                        img_tag = release_tag if release_tag else TagBuilder(sha, base_tag).get_deployment_tag()
                        env_image_full = build.full_image_name(img_tag)
                        clusters = global_env.clusters

                        log.info(f"Running deploy for {service_env.build} to {provider.name}")

                        for cluster in clusters:
                            try:
                                if not self.image_exists(env_image_full, build.registry, timeout):
                                    raise Exception(f".....ERROR: image {env_image_full} does not exist, failing deployment")

                                log.info(f"...configuring KUBECONFIG for {provider.name}/{cluster.name}")
                                authenticator = Auth(cluster, provider)
                                if not authenticator.auth():
                                    raise Exception("Cluster authentication failed")
                            except Exception as e:
                                all_success = False
                                log.error(f"...ERROR: deploy failed: {e}")
                                continue

                            futures.update({
                                executor.submit(
                                    self.legacy_deploy_thread,
                                    cluster,
                                    env_image_full,
                                    img_tag,
                                    provider,
                                    service_env,
                                    sha,
                                    authenticator.get_kubeconfig_env()
                                ): cluster})

                for future in concurrent.futures.as_completed(futures):
                    cluster = futures[future]
                    try:
                        future.result()
                    except Exception as e:
                        all_success = False
                        log.error(f"...ERROR: thread failed: {e}")
                    else:
                        log.info(f"...Successfully updated {self.__service.name} in Environment {cluster.name}")
                    finally:
                        t_all.stop()
                break
        if not found:
            log.error(f"{environment} not found in Environments List. Please check manifest file entries.")
        return all_success


    def legacy_deploy_thread(self, cluster, env_image_full, img_tag, provider, service_env, sha, kube_env):
        thread_name = f"{provider.name}/{cluster.name}"
        threading.current_thread().name = thread_name
        t = DEFAULT_WRITER.new_timer(f"{self.__service.name}/{cluster.name} -- {env_image_full}")
        log.info(f"...deploying {env_image_full} to {cluster.name}")

        try:
            self.deploy(env_image_full, service_env.override_namespace, img_tag, kube_env)

        except Exception as e:
            log.error(f"...ERROR: DEPLOY failed for {self.__service.name} to Environment {cluster.name}: {e}")
            raise Exception(f"Thread {thread_name} failed")
        finally:
            t.stop()


    def argocd_deploy_all(self, environment: str, base_tag: str, sha: str, release_tag: str, timeout: int, release_branch: str) -> bool:
        self.__known_images: list[str] = []
        t_all = DEFAULT_WRITER.new_timer(f"{self.__service.name} -- total")
        retval = True

        try:
            for service_env_name in self.__service.environments:
                if service_env_name == environment:  # found a target
                    try:
                        service_env = self.__service.environments[service_env_name]
                        build_name = service_env.build
                        build = self.__service.builds.get(build_name)

                        log.info(f"Running argocd-deploy-git-write-back for {service_env.build}")

                        img_tag = release_tag if release_tag else TagBuilder(sha, base_tag).get_deployment_tag()
                        env_image_full = build.full_image_name(img_tag)

                        t = DEFAULT_WRITER.new_timer(f"{self.__service.name} -- {env_image_full}")

                        if not self.image_exists(env_image_full, build.registry, timeout):
                            raise Exception(f".....ERROR: image {env_image_full} does not exist, failing deployment")

                        self.git_write_back(environment, img_tag, release_branch)
                    except Exception as e:
                        log.error(f"...ERROR: argocd-deploy-git-write-back failed for {self.__service.name}: {e}")
                        if self.__try_all:
                            retval = False
                        else:
                            return False
                    finally:
                        t.stop()

        finally:
            t_all.stop()

        return retval

    def image_exists(self, full_img_name: str, registry: str, timeout: int) -> bool:
        if full_img_name in self.__known_images:
            log.info("..skipping image check, image already found")
            return True
        else:
            log.info("...checking if image exists")
            registry = get_registry(registry, ProcessRunner(2))
            img_exists = registry.confirm_image_exists(full_img_name, timeout)
            if img_exists:
                self.__known_images.append(full_img_name)
            return img_exists

    def deploy(self, env_image_full: str, override_namespace: str, img_tag: str, additional_env: dict = {}) -> None:
        namespace = self.__service.deployment.namespace
        overrided_namespace = override_namespace if override_namespace else namespace

        if self.__service.deployment.type == DeploymentType.command:
            log.info("...running deploy command:")
            # in config we use ${deploy_namespace} and ${env_image_full} variables
            deploy_command = self.__service.deployment.command \
                .replace("${deploy_namespace}", namespace) \
                .replace("${env_image_full}", env_image_full) \
                .replace("${override_namespace:-$deploy_namespace}", overrided_namespace) \
                .replace("${env_image_tag}", img_tag)

            command_result = ProcessRunner(2).run_command_retry(deploy_command, additional_env)

            if command_result.returncode == 0:
                log.info(command_result.stdout.decode('utf-8'))
            else:
                raise Exception(f"Deploy command failed {env_image_full}")

    def git_write_back(self, environment: str, img_tag: str, release_branch: str) -> str:
        if self.__service.deployment.type == DeploymentType.argocd:
            # initializing variables to empty strings for reference in exceptions
            images_values_filename_basepath = ""
            images_values_filename_fullpath = ""
            image_tag_json_path = ""

            # Clone ArgoCD release branch
            try:
                clone_argocd_repo(release_branch)
            except Exception as e:
                log.error(f"...ERROR: GIT-Write-back failed cloning the release-branch {release_branch} in the argocd-repository: {e}")

            # Update the image-tags in the images.yaml files
            try:
                log.info("...running deploy argocd git-write-back:")

                # make sure the environment is matching with the argocd-git-folder-structure
                argocd_environment = "prod" if environment == "production" else environment

                # load the image-values-filename and the json-path for updating the image-tag from the service-file
                images_values_filename_basepath = f"environments/{argocd_environment}/{self.__service.deployment.application_path}/{self.__service.deployment.values_file}"
                images_values_filename_fullpath = f"{ARGOCD_REPO_PATH}/{images_values_filename_basepath}"
                image_tag_json_path = self.__service.deployment.image_tag_json_path

                log.info(f"Updating {images_values_filename_fullpath} at {image_tag_json_path} with image-tag: {img_tag}...")

                # load the image-values-file and update the image-tag
                with open(images_values_filename_fullpath, "r") as values_file:
                    deployment_config = yaml.safe_load(values_file)
                    jsonpath_expr = parse(image_tag_json_path)
                    jsonpath_expr.update(deployment_config, img_tag)

                # write the updated image-tag back to the values-file
                with open(images_values_filename_fullpath, "w") as values_file:
                    yaml.dump(deployment_config, values_file)

            except Exception as e:
                log.error(f"...ERROR: GIT-Write-Back failed writing image-tag to yaml file for {self.__service.name} to file {images_values_filename_fullpath} at path {image_tag_json_path} with image-tag: {img_tag}: {e}")

            # Commit the updated images.yaml to ArgoCD git repository
            try:
                # commit and push the changed file to git
                commit_argocd_repo_changes(images_values_filename_basepath)
                log.info(f"...Successfully updated GIT-Write-Back for {self.__service.name} to file {images_values_filename_fullpath} at path {image_tag_json_path} with image-tag: {img_tag}")
            except Exception as e:
                log.error(f"...ERROR: GIT-Write-Back failed committing the image-tags to argocd repository for {self.__service.name} to file {images_values_filename_fullpath} at path {image_tag_json_path} with image-tag: {img_tag}: {e}")


        else:
            raise Exception(f"Wrong DeploymentType set: {self.__service.deployment.type} instead of {DeploymentType.argocd}")
