import yaml
import os
from enum import Enum

from src.env import get_repo_dir


class Provider(Enum):
    gcp = 1
    aws = 2
    azure = 3


class Cluster:
    name: str = None
    region: str = None
    project: str = None
    zone: str = None
    profile: str = None
    resource_group: str = None

    def __init__(self, cluster_config: dict):
        self.name = cluster_config["name"]
        self.region = cluster_config.get("region")
        self.project = cluster_config.get("project")
        self.zone = cluster_config.get("zone")
        self.profile = cluster_config.get("profile")
        self.resource_group = cluster_config.get("resource_group")


class Environment:
    name: str = None
    provider: Provider = None
    clusters: list[Cluster] = []

    def __init__(self, name: str, environment_config: dict):
        self.validate_config(environment_config)

        provider_str = environment_config["provider"]
        provider = None

        if provider_str == "gcp":
            provider = Provider.gcp
        elif provider_str == "aws":
            provider = Provider.aws
        elif provider_str == "azure":
            provider = Provider.azure
        else:
            raise TypeError(f"Unknown provider {provider_str}")

        self.name = name
        self.provider = provider
        self.clusters = [Cluster(cluster)
                         for cluster in environment_config["clusters"]]

    @staticmethod
    def validate_config(environment_config: dict) -> None:
        if not isinstance(environment_config["clusters"], list):
            raise TypeError(f"Environment.clusters must be a list")
        if not isinstance(environment_config["provider"], str):
            raise TypeError(f"Environment.provider must be a str")

        for cluster in environment_config["clusters"]:
            Environment.check_cluster(cluster, environment_config["provider"])

    @staticmethod
    def check_cluster(cluster: dict, provider: str) -> None:
        if not isinstance(cluster["name"], str):
            raise TypeError(f"Environment.cluster.name must be a str")

        if provider == "gcp":
            if not isinstance(cluster["region"], str):
                raise TypeError( f"Environment.cluster.region must be a str for gcp provider")
            if not isinstance(cluster["project"], str):
                raise TypeError(f"Environment.cluster.project must be a str for gcp provider")

        if provider == "aws":
            if not isinstance(cluster["region"], str):
                raise TypeError(f"Environment.cluster.region must be a str for aws provider")

        if provider == "azure":
            if not isinstance(cluster["resource_group"], str):
                raise TypeError(f"Environment.cluster.resource_group must be a str for azure provider")


class Environments:
    __environments: list[Environment] = []

    def __init__(self):
        repo_dir = get_repo_dir()
        environments_path = "./scripts/deployment_v2/environments.yaml"
        environments_filename = os.path.join(repo_dir, environments_path)
        with open(environments_filename) as file:
            raw_environments = yaml.safe_load(file)["environments"]
            self.__environments = [
                Environment(environment, raw_environments[environment])
                for environment in raw_environments
            ]

    def get_environment_by_name(self, env_name: str) -> Environment:
        filtered_items = [e for e in self.__environments if e.name == env_name]
        return filtered_items[0] if len(filtered_items) > 0 else None
