import os
from enum import Enum
from pathlib import Path
from typing import List, Dict, Union

import yaml

"""
Classes to be populated by a service yaml file.

Helper methods exist, but these are mostly just data-objects.

At a very high level, the classes in this file are structured as:

Service
- name: string name of the service
- image_config: map of common image configurations used for container image builds
- builds: map of `Build` objects by build name
- deployment: a single `Deployment` object
- environments: map of `ServiceEnvironment` objects by environment name

Build, Deployment and ServiceEnvironment do not contain deeply complex structures.
"""


def load_service(filename: Path):
    with open(filename) as file:
        y = yaml.safe_load(file)
    service = Service(y)
    return service


class BuildType(Enum):
    bazel_push = 1
    docker_file = 2
    bazel_push_oci = 3


class Build:
    """
    Defines a single build rule
    """

    # Attributes from the config
    name: str = None
    image_config = None
    registry: str = None
    repository: str = None
    image: str = None
    type: BuildType
    buildImage: bool
    prepare_commands: List[str] = []
    required_builds: List[str] = []
    additional_bazel_config: List[str] = []
    # type = BAZEL_PUSH
    bazel_path: str = None
    bazel_run_defs: Dict[str, str] = {}
    # type = DOCKER_FILE
    docker_file: Path = None
    workdir: Path = None
    bazel_deps: List[str] = []
    docker_build_args: Dict[str, str] = {}
    docker_deps: List[Path] = []
    local_tags: List[str] = []
    docker_labels: Dict[str, str] = {}

    # Attributes for state
    is_built: bool = False

    def __init__(self, name: str, config: dict):
        self.validate_config(config)
        # Required
        self.name = name
        self.registry = config["registry"]
        self.repository = config["repository"]
        self.image = config["image"]
        self.type = BuildType[config["type"]]
        # Optional
        self.buildImage = config.get("buildImage", True)
        self.prepare_commands = config.get("prepare_commands", [])
        self.required_builds = config.get("required_builds", [])
        self.additional_bazel_config = config.get("additional_bazel_config", [])
        self.local_tags = config.get("local_tags", [])
        self.bazel_path = config.get("bazel_path", "")
        self.bazel_run_defs = config.get("bazel_run_defs", {})

        docker_file = config.get("docker_file", "")
        if docker_file:
            self.docker_file = Path(docker_file).resolve()

        self.docker_labels = config.get("docker_labels",{})
        if self.docker_labels and self.docker_file:
            self._append_labels_to_dockerfile()

        workdir = config.get("workdir", "")
        if workdir:
            self.workdir = Path(workdir).resolve()

        self.bazel_deps = config.get("bazel_deps", [])
        self.docker_build_args = config.get("docker_build_args", {})

        self.docker_deps = []
        for docker_dep in config.get("docker_deps", []):
            self.docker_deps.append(Path(docker_dep).resolve())

        if os.getenv("USE_REMOTE_EXECUTION") == 'true':
            self.additional_bazel_config.append("--config=engflow")
            self.additional_bazel_config.append("--verbose_failures")
            self.additional_bazel_config.append("--remote_upload_local_results=false")

    def full_image_name(self, tag: str):
        return self.registry + '/' + self.repository + '/' + self.image + ':' + tag

    def _append_labels_to_dockerfile(self):
    
        with open(self.docker_file, "r") as file:
            docker_content = file.readlines()

        with open(self.docker_file, "a") as file:
            for k, v in self.docker_labels.items():
                label_line = f'LABEL "{k}"="{v}"\n'

                # Check if label exists
                if not any(line.strip() == label_line.strip() for line in docker_content):
                    file.write(label_line)

    @staticmethod
    def validate_config(config: dict):
        if not isinstance(config, dict):
            raise TypeError("Build config must be a dictionary")
        cls = "Build[]"
        _validate_str(cls, config, "registry")
        _validate_str(cls, config, "repository")
        _validate_str(cls, config, "image")
        _validate_str(cls, config, "type")
        _validate_list_optional(cls, config, "prepare_commands")
        _validate_list_optional(cls, config, "required_builds")
        _validate_list_optional(cls, config, "additional_bazel_config")
        _validate_list_optional(cls, config, "local_tags")
        _validate_str_optional(cls, config, "bazel_path")
        _validate_dict_optional(cls, config, "bazel_run_defs")
        _validate_str_optional(cls, config, "docker_file")
        _validate_str_optional(cls, config, "workdir")
        _validate_list_optional(cls, config, "bazel_deps")
        _validate_dict_optional(cls, config, "docker_build_args")
        _validate_list_optional(cls, config, "docker_deps")
        _validate_dict_optional(cls, config, "docker_labels")


class DeploymentType(Enum):
    command = 1
    argocd = 2


class Deployment:
    """
    Defines a deployment action
    """

    # Required
    type: DeploymentType

    # Optional / Dependant on DeploymentType
    namespace: str = None
    command: str = None
    application_path: str = None
    values_file: str = None
    image_tag_json_path: str = None

    def __init__(self, config: dict):
        self.validate_config(config)
        self.type = DeploymentType[config["type"]]
        if self.type == DeploymentType.command:
            self.namespace = config["namespace"]
            self.command = config["command"]
        elif self.type == DeploymentType.argocd:
            self.application_path = config["application_path"]
            self.values_file = config["values_file"]
            self.image_tag_json_path = config["image_tag_json_path"]

    @staticmethod
    def validate_config(config: dict):
        if not isinstance(config, dict):
            raise TypeError("Deployment config must be a dictionary")
        cls = "Deployment"
        _validate_str(cls, config, "type")
        if config["type"] == DeploymentType.command:
            _validate_str(cls, config, "namespace")
            _validate_str(cls, config, "command")
        if config["type"] == DeploymentType.argocd:
            _validate_str(cls, config, "application_path")
            _validate_str(cls, config, "values_file")
            _validate_str(cls, config, "image_tag_json_path")



class ServiceEnvironment:
    """
    Defines an environment for service deployment
    """

    # Required
    name: str = None
    targets: List[str] = []
    build: str = None
    notify_slack: bool = False
    notify_pr_bot: bool = False
    override_namespace: str = None

    # Optional

    def __init__(self, name: str, config: dict):
        self.validate_config(config)
        self.name = name
        self.targets = config["targets"]
        self.build = config["build"]
        self.notify_slack = config.get("notify_slack")
        self.notify_pr_bot = config.get("notify_pr_bot")
        self.override_namespace = config.get("override_namespace")

    @staticmethod
    def validate_config(config: dict):
        if not isinstance(config, dict):
            raise TypeError("ServiceEnvironment config must be a dictionary")
        cls = "ServiceEnvironments[]"
        _validate_list(cls, config, "targets")
        _validate_str(cls, config, "build")
        _validate_bool(cls, config, "notify_slack")
        _validate_bool(cls, config, "notify_pr_bot")


class Service:
    """
    Defines a service
    """

    # Required
    name: str = None
    builds: Dict[str, Build] = {}
    imageConfig: Dict[str, Union[List, str]] = {}
    deployment: Deployment = None
    deploymentList: Dict[str, Union[List, str]] = None
    environments: Dict[str, ServiceEnvironment] = {}

    def __init__(self, config: dict):
        self.validate_config(config)
        self.name = config["name"]
        self.deployment = Deployment(config["deployment"])
        self.builds = {}
        for build_name, build in config["build"].items():
            try:
                build |= {k: v for k, v in config["image_config"].items() if k not in build}
            except KeyError:
                pass
            self.builds[build_name] = Build(build_name, build)
        self.environments = {}
        for environment_name, environment in config["environments"].items():
            self.environments[environment_name] = ServiceEnvironment(environment_name, environment)
        try:
            self.deploymentList = config["deploymentList"]
        except KeyError:
            pass

    @staticmethod
    def validate_config(config: dict):
        if not isinstance(config, dict):
            raise TypeError("Service config must be a dictionary")
        cls = "Service"
        _validate_str(cls, config, "name")
        _validate_dict(cls, config, "deployment")
        _validate_dict(cls, config, "build")
        _validate_dict(cls, config, "environments")


def _validate_str(cls: str, config: dict, key: str):
    if key not in config or not config[key]:
        raise ValueError(f"{cls}.{key} is required")
    if not isinstance(config[key], str):
        raise TypeError(f"{cls}.{key} must be a string")


def _validate_str_optional(cls: str, config: dict, key: str):
    if key not in config:
        return
    if not config[key]:
        raise ValueError(f"{cls}.{key} must have a value")
    if not isinstance(config[key], str):
        raise TypeError(f"{cls}.{key} must be a string")


def _validate_bool(cls: str, config: dict, key: str):
    if key not in config:
        raise ValueError(f"{cls}.{key} is required")
    if not isinstance(config[key], bool):
        raise TypeError(f"{cls}.{key} must be a boolean")


def _validate_list(cls: str, config: dict, key: str):
    if key not in config:
        raise ValueError(f"{cls}.{key} is required")
    if not isinstance(config[key], list):
        raise TypeError(f"{cls}.{key} must be a list")
    if len(config[key]) < 1:
        raise ValueError(f"{cls}.{key} must have at least one element")


def _validate_list_optional(cls: str, config: dict, key: str):
    if key not in config:
        return
    if not isinstance(config[key], list):
        raise TypeError(f"{cls}.{key} must be a list")
    if len(config[key]) < 1:
        raise ValueError(f"{cls}.{key} must have at least one element")


def _validate_dict(cls: str, config: dict, key: str):
    if key not in config:
        raise ValueError(f"{cls}.{key} is required")
    if not isinstance(config[key], dict):
        raise TypeError(f"{cls}.{key} must be a dictionary")
    if len(config[key].keys()) < 1:
        raise ValueError(f"{cls}.{key} must have at least one element")


def _validate_dict_optional(cls: str, config: dict, key: str):
    if key not in config:
        return
    if not isinstance(config[key], dict):
        raise TypeError(f"{cls}.{key} must be a dictionary")
    if len(config[key].keys()) < 1:
        raise ValueError(f"{cls}.{key} must have at least one element")
