import os
import logging
from pathlib import Path
from github import Github, Auth, GithubException

import semver
import pygit2
from datetime import datetime, date
import re
import shutil

from src.env import ARGOCD_REPO_PATH, get_repo_dir, get_git_ssh_keys, is_argocd_repo, get_argocd_github_access_token
from src.git_commit_messages import argocd_pr_commit_message

from src.process import ProcessRunner
from subprocess import CalledProcessError

log = logging.getLogger(__name__)

repo_dir = get_repo_dir()
sha_file = Path(f"{repo_dir}/scripts/deployment_v2/sha.txt")
ARGOCD_REPO_URL = "git@github.com:fivetran/argocd-alpha.git"
ARGOCD_MAIN_BRANCH="main"
process_runner = ProcessRunner(1)
CREATE_BRANCH_RETRIES = 0

def init_repo(repo_path: str):
    return pygit2.Repository(pygit2.discover_repository(repo_path))

def git_sha():
    if sha_file.is_file():
        with open(sha_file) as file:
            return file.read().strip()

    return str(init_repo(get_repo_dir()).head.target)[0:8]

def find_last_release(base_tag = 'release'):
    # find all releases
    repo = init_repo(get_repo_dir())
    releases = []
    commits = 1000  # Actually counting this is hard for pygit2. We have to walk the commit tree and that is slow

    # loop until we have refs OR until we hit 50k commits. We don't want to be stuck here forever
    while len(releases) == 0 and commits < 50000:
        releases = [r for r in repo.references if re.compile(r"^refs/tags/" + re.escape(base_tag)).match(r)]
        if len(releases) == 0 and repo.is_shallow:
            # we need to fetch more commits from git
            commits += 1000
            log.info(f"No releases found, fetching more commits ({commits})")
            fetch_more_commits(repo, commits)

    releases_as_semver = (map(lambda x: semver.VersionInfo.parse(x.split('-')[1]), releases))
    return str(max(releases_as_semver))


def fetch_more_commits(repo: pygit2.Repository, currentCommitCount: int) -> int:
    if "origin" in repo.remotes.names():
        targetCommitCount = currentCommitCount + 1000
        callbacks = get_git_callbacks()
        origin = repo.remotes["origin"]
        origin.fetch(depth=targetCommitCount, callbacks=callbacks)
        return targetCommitCount
    else:
        raise Exception("No 'origin' remote found")

def get_next_release(base_tag, is_hotfix=False):
    version = None
    last_version = str(semver.VersionInfo.parse(find_last_release(base_tag)))
    if is_hotfix:
        version = semver.bump_minor(last_version)
    else:
        version = semver.bump_major(last_version)
    date = datetime.today().strftime("%Y%m%d")
    return f"{base_tag}-{version}-{date}"

def apply_tag_to_head(release_string):
    signature = pygit2.Signature('Fivetran Buildkite', 'buildkite@fivetran.com')
    repo = init_repo(get_repo_dir())
    repo.create_tag(release_string, str(repo.head.peel().id),
            pygit2.enums.ObjectType.COMMIT, signature, f"Release {release_string} from Fivetran CI")

def release_tag_from_head(base_tag = ""):
    repo = init_repo(get_repo_dir())
    for r in (r for r in repo.references):
        if (re.compile(r"^refs/tags/" + re.escape(base_tag)).match(r)
          and (repo.references[r].peel().id == repo.head.target)):
            return re.sub(r"^refs/tags/", "", r)

def is_hotfix():
    repo = init_repo(get_repo_dir())
    if 'Merge branch \'hotfix' in repo[repo.head.target].message:
        return True

def get_branch_name(environment: str, workflow: str = ""):
    buildkite_metadata = get_buildkite_metadata("ARGOCD_RELEASE_BRANCHNAME")
    if buildkite_metadata != "":
        return buildkite_metadata
    else:
        release_branch = ""
        release_env = ""
        if environment == "qe":
            # qe doesn't have tags in engineering git-repo, so use integration for it.
            release_env = "integration"
        if  environment == "staging":
            # staging is tagged as 'integration-***'
            release_env = "integration"
        elif environment == "production":
            # production is tagged as 'release-***'
            release_env = "release"

        existing_tag = release_tag_from_head(release_env)
        if existing_tag:
            release_branch = existing_tag
        else:
            release_branch = get_next_release(release_env, is_hotfix())

        if environment == "qe":
            # add qe in front of integration-branch-name to distinguish qe from staging
            release_branch = "qe-" + release_branch

        if workflow is not None and workflow != "":
            release_branch = release_branch + "-" + workflow

        set_buildkite_metadata("ARGOCD_RELEASE_BRANCHNAME", release_branch)
        return release_branch

def get_git_callbacks():
    public_key, private_key = get_git_ssh_keys()
    keypair = pygit2.KeypairFromMemory("git", public_key, private_key, "")
    return pygit2.RemoteCallbacks(credentials=keypair)

def clone_argocd_repo(checkout_branch: str = ARGOCD_MAIN_BRANCH, path = ARGOCD_REPO_PATH):
    if is_argocd_repo(path):
        log.info(f"clone_argocd_repo: path already exists; checking out branch {checkout_branch} in existing folder {path}")
        repo = init_repo(path)
        repo.checkout(f"refs/heads/{checkout_branch}")
        return repo
    else:
        callbacks = get_git_callbacks()

        log.info(f"clone_argocd_repo: repo-path doesn't exist; cloning argocd branch {checkout_branch} into new folder")

        return pygit2.clone_repository(url=ARGOCD_REPO_URL, path=path, checkout_branch=checkout_branch, callbacks=callbacks)

def create_argocd_repo_branch(branch_name: str, checkout: bool = True, push: bool = True, path = ARGOCD_REPO_PATH):
    repo = init_repo(path.resolve().as_posix())

    log.info(f"create_argocd_repo_branch: creating argocd branch {branch_name}")
    new_branch = repo.branches.create(branch_name, repo.revparse_single('HEAD'))
    new_branch_ref = repo.lookup_reference(new_branch.name)

    if checkout:
        log.info(f"create_argocd_repo_branch: checking out branch ref {new_branch_ref}")
        repo.checkout(new_branch_ref)

    if push:
        try:
            log.info(f"create_argocd_repo_branch: pushing branch ref {new_branch_ref.name}")
            callbacks = get_git_callbacks()
            repo.remotes["origin"].push([new_branch_ref.name], callbacks=callbacks)

            log.info(f"create_argocd_repo_branch: return branch {new_branch}")

            return new_branch
        except pygit2.GitError as e:
            # _pygit2.GitError: cannot push non-fastforwardable reference means the branch already exists:
            # add an updated suffix to the branchname
            # store the updated branchname in the buildkite-metadata
            # call create_argocd_repo_branch with the updaed branchname
            global CREATE_BRANCH_RETRIES
            CREATE_BRANCH_RETRIES += 1
            release_branch_name = f"{branch_name}-{CREATE_BRANCH_RETRIES}"
            set_buildkite_metadata("ARGOCD_RELEASE_BRANCHNAME", release_branch_name)
            create_argocd_repo_branch(release_branch_name)



def delete_argocd_repo_branch(branch_name: str, push: bool = True):
    repo = init_repo(ARGOCD_REPO_PATH.resolve().as_posix())

    repo.checkout(f"refs/remotes/origin/{ARGOCD_MAIN_BRANCH}")

    repo.branches.delete(branch_name)

    if push:
        callbacks = get_git_callbacks()
        repo.remotes["origin"].push([f":refs/heads/{branch_name}"], callbacks=callbacks)

def get_buildkite_metadata(key: str) -> str:
    command = f"buildkite-agent meta-data get {key}"
    try:
        command_result = process_runner.run_command(command)
        return command_result.stdout.decode('utf-8')
    except CalledProcessError:
        log.info(f"buildkite-metadata {key} not found; proceeding")
        return ""


def set_buildkite_metadata(key: str, value: str):
    command = f"buildkite-agent meta-data set {key} {value}"
    command_result = process_runner.run_command(command)
    if command_result.returncode == 0:
        return command_result.stdout.decode('utf-8')
    else:
        log.error(f"setting buildkite-metadata {key} to {value} errored")

def git_add(changed_file_path: str):
    command = f"git add {changed_file_path}"
    process_runner.run_command(command)


def git_commit(commit_message: str):
    command = f'git commit -m "{commit_message}"'
    process_runner.run_command(command)


def git_pull(rebase: bool = True):
    command = "git pull --rebase" if rebase else "git pull"
    process_runner.run_command(command)


def git_push():
    command = "git push"
    process_runner.run_command(command)


def git_set_user_config():
    user_email_command = 'git config user.email "buildkite@fivetran.com"'
    process_runner.run_command(user_email_command)
    user_name_command ='git config user.name "Fivetran Buildkite"'
    process_runner.run_command(user_name_command)


def commit_argocd_repo_changes(changed_file_path: str, push: bool = True, path = ARGOCD_REPO_PATH):
    os.chdir(path.resolve().as_posix())

    try:
        git_set_user_config()
        git_add(changed_file_path)
        git_commit(f"Updating {changed_file_path}")
        git_pull()
    except CalledProcessError as error:
        print (error)
        raise error

    if push:
        push_done = False
        max_retries = 100 # allow for lot's of app's to be deployed more or less in parallel; increase when needed
        while not push_done and max_retries > 0:
            max_retries -= 1
            try:
                git_push()
                push_done = True
            except CalledProcessError:
                git_pull(True)


def create_argocd_repo_pull_request(branch_name: str):
    auth = Auth.Token(get_argocd_github_access_token())

    # Public Web Github
    github = Github(auth=auth)

    repo = github.get_repo("fivetran/argocd-alpha")
    body = argocd_pr_commit_message.format(branch_name=branch_name, date=date.today().strftime("%d %B %Y"))
    try:
        pr =  repo.create_pull(base="main", head=branch_name, title=branch_name, body=body)
        pr.set_labels("production-impact:none")

        return (repo, pr)
    except GithubException as err:
        if (err.status == 422 and
            err.data["errors"] and
            len(err.data["errors"]) > 0 and
            err.data["errors"][0]["resource"] == 'PullRequest' and
            "No commits between main and" in err.data["errors"][0]["message"]
        ):
            log.info(f"No PR created, because of Github error: {err.data['errors'][0]['message']}; no further action required")
        else:
            raise err

def cleanup_argocd_temp_repo(path = ARGOCD_REPO_PATH):
    try:
        shutil.rmtree(path)
    except Exception as e:
        print(f"...ERROR: cleaning up tmp argocd repo path: {e}")
